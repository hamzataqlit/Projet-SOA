import React from 'react';

const Fail = () => {
    return (
        <div>
            Fail
            Fail
        </div>
    );
};

export default Fail;