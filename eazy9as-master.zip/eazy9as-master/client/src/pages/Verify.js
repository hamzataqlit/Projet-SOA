import React from 'react';

const Verify = () => {
    return (
        <div>
            Verify
        </div>
    );
};

export default Verify;