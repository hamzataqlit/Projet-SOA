import React from 'react';

const Forget = () => {
    return (
        <div>
            Forget
        </div>
    );
};

export default Forget;