import React from 'react';

const ResetPassword = () => {
    return (
        <div>
            ResetPassword
        </div>
    );
};

export default ResetPassword;